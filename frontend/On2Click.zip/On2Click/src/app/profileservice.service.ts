
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Registration } from './registration';
@Injectable({
  providedIn: 'root'
})
export class ProfileserviceService {
 
  constructor(private http: HttpClient) { }
  viewProfile(cid:string): Observable<Registration> {
    return this.http.get<Registration>(`http://localhost:8080/user/viewprofile/${cid}`);
  }
  editProfile(cid:string,registration:Registration):Observable<Registration> 
  { 
    return this.http.post<Registration>(`http://localhost:8080/user/updateprofile/${cid}`,registration);
  }
  deleteProfile(cid:string):Observable<Registration> 
  { 
    return this.http.delete<Registration>(`http://localhost:8080/user/deleteuser/${cid}`,{responseType:'text' as 'json'});
  }
}