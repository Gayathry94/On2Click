import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Regis } from './regis';
import { Product } from './product';
import { Querie } from './querie';
import { Complaints } from './complaints';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
  getProfile(tc: string): Observable<Regis[]> {
    return this.http.get<Regis[]>(`http://localhost:8080/Admin/Aviewprofile/${tc}`);
  }
  getProduct(type: string): Observable<Product[]> {
    return this.http.get<Product[]>(`http://localhost:8080/Admin/Aviewproduct/${type}`);
  }
  getComplaint():Observable<Complaints[]> {
    return this.http.get<Complaints[]>(`http://localhost:8080/Admin/viewcomplaint`);

}
getquerie():Observable<Querie[]> {
  return this.http.get<Querie[]>(`http://localhost:8080/Admin/viewquerie`);

}
}
