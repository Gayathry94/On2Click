import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';

import { ContactComponent } from './contact/contact.component';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { RegserviceService } from './regservice.service';
import { AccountComponent } from './account/account.component';
import { LogserviceService } from './logservice.service';
import { ProfileComponent } from './profile/profile.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { BuyComponent } from './buy/buy.component';
import { MproductComponent } from './mproduct/mproduct.component';
import { MprofileComponent } from './mprofile/mprofile.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';
import { DistributorprofileComponent } from './distributorprofile/distributorprofile.component';
import { AdminComponent } from './admin/admin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { CreationComponent } from './creation/creation.component';
import { EprofileComponent } from './eprofile/eprofile.component';
import { DprofileComponent } from './dprofile/dprofile.component';
import { ViewprodComponent } from './viewprod/viewprod.component';
import { ViewyprodComponent } from './viewyprod/viewyprod.component';
import { EproductComponent } from './eproduct/eproduct.component';
import { QuerieComponent } from './querie/querie.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { VieworderComponent } from './vieworder/vieworder.component';
import { AproductComponent } from './aproduct/aproduct.component';
import { AprofileComponent } from './aprofile/aprofile.component';
import { ComComponent } from './com/com.component';
import { ViewquerieComponent } from './viewquerie/viewquerie.component';









@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
   
    ContactComponent,
    HomeComponent,
    AccountComponent,
    ProfileComponent,
    AddproductComponent,
    
    BuyComponent,
    MproductComponent,
    MprofileComponent,
    CustomerprofileComponent,
    DistributorprofileComponent,
    AdminComponent,
    AdminhomeComponent,
    CreationComponent,
    EprofileComponent,
    DprofileComponent,
    ViewprodComponent,
    ViewyprodComponent,
    EproductComponent,
    QuerieComponent,
    ViewcartComponent,
    VieworderComponent,
    AproductComponent,
    AprofileComponent,
    ComComponent,
    ViewquerieComponent,

    
    
    
   

  
   
  ],
  imports: [
    BrowserModule,
    
    AppRoutingModule,FormsModule,HttpClientModule,ToastrModule.forRoot(),BrowserAnimationsModule
  ],
  providers: [RegserviceService,LogserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
