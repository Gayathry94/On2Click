import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegserviceService } from '../regservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { filehandle } from '../file-handle';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrl: './addproduct.component.css'
})
export class AddproductComponent  implements OnInit{
  cid: string = '';

  errorMessage: string = '';
pr:Product=new Product(0,"","","",0,"",0,"")
message:any;
constructor(private ser:RegserviceService,private route:Router,private sanitizer:DomSanitizer,private rout:ActivatedRoute)
{

}
  ngOnInit(): void {
    console.log('produc initiated')

    console.log('view initiated in product profile');
this.rout.params.subscribe(params => {
    this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
    console.log('CID:is', this.cid);
    if (this.cid) {
      this.prodReg(); // Call method to load profile if cid is provided
    } else {
      console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
    }
  });


  }

  prodReg() {
    let resp = this.ser.prodReg1(this.pr,this.cid);
    resp.subscribe(
      (data: any) => {
        if (data && data.success) {
          this.message = "Data added successfully.";
          alert(this.message); // Provide a success message
          // You might want to reset the form or do other actions after successful addition
        } else {
          this.message = "successfully added";
           // Provide an appropriate error message
          alert(this.message);
          this.route.navigate([`/Profile/${this.cid}`]);
        }
      },
      (error) => {
        console.error('Error occurred:', error); // Handle error case
        // You might want to show an error message to the user
      }
    );
  }

}

