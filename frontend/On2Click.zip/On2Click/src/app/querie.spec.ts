import { Querie } from './querie';

describe('Querie', () => {
  it('should create an instance', () => {
    expect(new Querie()).toBeTruthy();
  });
});
