export class Complaints {
    constructor(public id:number,public cid:String,public name:string,public mailid:string,public des:String )
    {

    }

}
