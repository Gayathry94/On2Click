import { Component, OnInit } from '@angular/core';
import { Regis } from '../regis';
import { RegserviceService } from '../regservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-creation',
  templateUrl: './creation.component.html',
  styleUrl: './creation.component.css'
})
export class CreationComponent implements OnInit {


  reg:Regis=new Regis("","","","","","","","","","","");
  message:any;
  constructor(private ser:RegserviceService,private route:Router)
  {

  }
  ngOnInit(): void {
    // Your initialization logic goes here
    console.log('Component initialized');
  }
public userReg()
{
  let resp=this.ser.userReg1(this.reg);
  resp.subscribe(
    (data) => {
      this.message = data;
      alert('Successfully added');
      this.route.navigate(['/Account']); // Navigate on successful registration
    },
    (error) => {
      console.error('Error occurred:', error); // Handle error case
      // You might want to show an error message to the user
    }
  );

  }
}

