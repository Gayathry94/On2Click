import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { Product } from '../product';

import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewprod',
  templateUrl: './viewprod.component.html',
  styleUrl: './viewprod.component.css'
})
export class ViewprodComponent implements OnInit {

  cid: string = '';

  errorMessage: string = '';

  productDetails:Product[]=[];
constructor(private ser:ProductserviceService,private router:ActivatedRoute)
{

}


ngOnInit(): void {
  console.log('view initiated in view profile');
  this.router.params.subscribe(params => {
      this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
      console.log('CID:is', this.cid);
      if (this.cid) {
        this.getAllProducts();
      } else {
        console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
      }
    });
  
  
  

  
}
public getAllProducts()
{
  this.ser.getAllProducts().subscribe((resp:Product[])=>{
    console.log(resp);
    this.productDetails=resp
    
  },(error:HttpErrorResponse)=>{
    console.log(error);
  }
  );
}



}



