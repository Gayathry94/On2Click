import { Userac } from './userac';

describe('Userac', () => {
  it('should create an instance', () => {
    expect(new Userac()).toBeTruthy();
  });
});
