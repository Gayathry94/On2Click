export class Userac {
    constructor(public acno: string,
        public state: string,
        public branch: string,
        public ifsc:String,
        public upid:String,
       
        ){
            
        }
}
