export class Admin {

    constructor(public uname: string,
        public pass: string)
        {

        }

}
