import { filehandle } from "./file-handle";

export class Product {
    constructor(public id:number,
        public cid:string,
        public name: string,
        public des: string,
        public quantity: number,
        public grade: string,
        public price: number,
        public p_point: string,
        
        
       )
        {
            
        }
}
