import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './login/login.component';

import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { AccountComponent } from './account/account.component';
import { ProfileComponent } from './profile/profile.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { CustomerprofileComponent } from './customerprofile/customerprofile.component';
import { DistributorprofileComponent } from './distributorprofile/distributorprofile.component';
import { AdminComponent } from './admin/admin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { MprofileComponent } from './mprofile/mprofile.component';
import { CreationComponent } from './creation/creation.component';
import { EprofileComponent } from './eprofile/eprofile.component';
import { DprofileComponent } from './dprofile/dprofile.component';
import { ViewprodComponent } from './viewprod/viewprod.component';
import { ViewyprodComponent } from './viewyprod/viewyprod.component';
import { EproductComponent } from './eproduct/eproduct.component';
import { QuerieComponent } from './querie/querie.component';
import { BuyComponent } from './buy/buy.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { VieworderComponent } from './vieworder/vieworder.component';
import { AprofileComponent } from './aprofile/aprofile.component';
import { AproductComponent } from './aproduct/aproduct.component';
import { ComComponent } from './com/com.component';
import { ViewquerieComponent } from './viewquerie/viewquerie.component';






const routes: Routes = [{path:'',component:HomeComponent},{path:'Home',component:HomeComponent},{path:'Login',component:LoginComponent},{path:'Contact/:cid',component:ContactComponent},{path:'Account',component:AccountComponent},{path:'Profile/:cid',component:ProfileComponent}
,{path:'Addproduct/:cid',component:AddproductComponent},{path:'Customerprofile/:cid',component:CustomerprofileComponent},
{path:'DistributorProfile',component:DistributorprofileComponent},{path:'Admin',component:AdminComponent},{path:'Adminhome',component:AdminhomeComponent}
,{path:'mprofile/:cid',component:MprofileComponent},{path:'Creation',component:CreationComponent},
{path:'Eprofile/:cid',component:EprofileComponent},{path:'Dprofile/:cid',component:DprofileComponent},{path:'Viewproduct/:cid',component:ViewprodComponent},
{path:'ViewyProd/:cid',component:ViewyprodComponent},{path:'Eproduct/:cid',component:EproductComponent},{path:'Querie',component:QuerieComponent},{path: 'Buy/:type/:cid',component:BuyComponent},{path:'Viewcart/:cid',component:ViewcartComponent},{path:'Vieworder/:cid',component:VieworderComponent},{path:'Aprofile/:tc',component:AprofileComponent},{path:'Aproduct/:type',component:AproductComponent}
,{path:'Complaint',component:ComComponent},{path:'Viewquerie',component:ViewquerieComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
