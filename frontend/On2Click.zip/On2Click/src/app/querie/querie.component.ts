import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { RegserviceService } from '../regservice.service';
import { Querie } from '../querie';
@Component({
  selector: 'app-querie',
  templateUrl: './querie.component.html',
  styleUrl: './querie.component.css'
})
export class QuerieComponent implements OnInit
{
  que:Querie=new Querie(0,"","","");
  message:any='';
  constructor(private router:ActivatedRoute,private route:Router,private ser:RegserviceService) { }
ngOnInit(): void {
  console.log('queries initiated')
}
public comReg1() {
  let resp = this.ser.querieReg(this.que);
  resp.subscribe(
    (data) => {
      this.message = data;
      console.log('Response from server:', data); // Log the response data
      alert('Successfully added, we will contact you soon');
      this.route.navigate(['/Home'])
    },
    (error) => {
      console.error('Error occurred:', error);
      alert('Error Occurred');
      // You might want to show an error message to the user
    }
  );
}



}
