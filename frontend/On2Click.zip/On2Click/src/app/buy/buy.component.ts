import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { BuyService } from '../buy.service';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrl: './buy.component.css'
})
export class BuyComponent implements OnInit
{

  cid: string = '';
type:string='';
  errorMessage: string = '';
id:number=0;
  productDetails:Product[]=[];
  constructor(private ser:ProductserviceService,private router:ActivatedRoute,private serv:BuyService,private route:Router)
{

}
ngOnInit(): void {
  console.log('view initiated in view buy product');
this.router.params.subscribe(params => {
    this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
    this.type=params['type'];
    console.log('CID:is', this.cid);
    console.log('type:',this.type);
    if (this.cid && this.type) {
      this.getProducts1(this.type,this.cid);
    } else {
      console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
    }
  });


}
public getProducts1(type:string,cid:String)
{
  console.log('cid inside getproduct1',cid);
  console.log('type inside getproduct1',type);
  this.ser.getProtype(this.type,this.cid).subscribe((resp:Product[])=>{
    console.log(resp);
    this.productDetails=resp
    
  },(error:HttpErrorResponse)=>{
    console.log(error);
  }
  );



}



addTocart(id:number)
{
  console.log('cid inside addtocart',this.cid);
  console.log('id inside addtocart',id);
  this.serv.addtoCart(this.cid,id).subscribe(
    (resp)=>{
      console.log(resp);
      if(resp){
        alert('product added sucessfully')
      }
    },
    (error)=>{
      console.log('error');
    }
  );
  
}

setType(type: string): void {
  this.type = type;
  console.log('Type set in customer profile:', this.type);
  
  // Now, construct the router link dynamically and navigate to it
  this.route.navigate(['/Buy', this.type, this.cid]);
}


}
