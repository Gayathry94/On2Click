import { Component, OnInit } from '@angular/core';

import { Product } from '../product';

import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-eproduct',
  templateUrl: './eproduct.component.html',
  styleUrl: './eproduct.component.css'
})
export class EproductComponent implements OnInit {
    cid: string = '';
    id: number = 0;
    message:String='';
    errorMessage: string = '';
  productDetails: Product[] = [];
  updatedProduct: Product = new Product(0,"","","",0,"",0,""); // Initialize updatedProduct

  constructor(private ser: ProductserviceService, private router: ActivatedRoute, private route: Router) { }

  ngOnInit(): void {
    console.log('view initiated in view profile');
    this.router.params.subscribe(params => {
      this.cid = params['cid'];
      console.log('CID:is', this.cid);
      if (this.cid) {
        this.getProducts(this.cid);
      } else {
        console.error('CID parameter is not provided.');
      }
    });
  }

  public getProducts(cid: string) {
    this.ser.getProducts(cid).subscribe(
      (resp: Product[]) => {
        console.log(resp);
        this.productDetails = resp;
        if (this.productDetails === null) {
          alert('You Have No products to Edit');
        }
      },
      (error: HttpErrorResponse) => {
        console.log(error);
      }
    );
  }

  public editPro(id: number, updatedProduct: Product) {
    console.log('Product ID:', id);
    console.log('CID:', this.cid);
    console.log('Updated Product:', updatedProduct);

    this.ser.editProduct(this.cid, id, updatedProduct).subscribe(
      (response: Product[]) => {
        console.log('Product updated successfully:', response);
      },
      (error) => {
        console.error('Error updating product:', error);
      }
    );
  }
    public DelPro(id: number)
    {
      
    console.log('hi'+id)
    console.log(this.cid)
    this.ser.deleteProduct(this.cid,id)
    .subscribe(
      response => {
        console.log(response);
        this.message = response;
        alert('product deleted succesfully')
        this.route.navigate(['/home']);
        
      },
      error => {
        console.log(error);
        this.message = 'Error deleting product.';
      });
  }
    }
    

