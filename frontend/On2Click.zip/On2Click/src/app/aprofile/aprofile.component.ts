import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Regis } from '../regis';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-aprofile',
  templateUrl: './aprofile.component.html',
  styleUrl: './aprofile.component.css'
})
export class AprofileComponent implements OnInit{
  tc: string = ''; // ensure string type
  type: string = ''; // ensure string type
  reg: Regis[] = [];

  constructor(private route: ActivatedRoute, private router: Router, private ser: AdminService) { }

  ngOnInit(): void {

    console.log('admin home');
    this.route.params.subscribe(params => {
      this.tc = params['tc']; // 'cid' should match the parameter name defined in the route
      console.log('tc in admin profile:', this.tc);
      if(this.tc)
{
  this.getProfile(this.tc);
}
    });
    
  }

  

  public getProfile(tc: string) {
    console.log('hi', tc);
    this.ser.getProfile(tc).subscribe((resp: Regis[]) => {
      console.log(resp);
      this.reg = resp;
    }, (error: HttpErrorResponse) => {
      console.log(error);
    });
  }
}
