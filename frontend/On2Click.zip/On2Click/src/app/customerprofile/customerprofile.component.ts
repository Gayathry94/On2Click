import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customerprofile',
  templateUrl: './customerprofile.component.html',
  styleUrl: './customerprofile.component.css'
})
export class CustomerprofileComponent implements OnInit
{
  cid: string='';
  type: string = '';
  constructor(private route:ActivatedRoute,private router:Router ) { }
  
  
  ngOnInit(): void {

console.log('customer profile initiated')

    this.route.params.subscribe(params => {
      this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
      console.log('CID value in customer profile:', this.cid);
    });
  }
  setType(type: string): void {
    this.type = type;
    console.log('Type set in customer profile:', this.type);
    
    // Now, construct the router link dynamically and navigate to it
    this.router.navigate(['/Buy', this.type, this.cid]);
  }

}
