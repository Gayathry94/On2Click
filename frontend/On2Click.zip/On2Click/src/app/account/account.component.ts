import { Component, OnInit } from '@angular/core';
import { RegserviceService } from '../regservice.service';
import { Userac } from '../userac';
import { Router } from '@angular/router';
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent implements OnInit {
  ac:Userac=new Userac("","","","","")
  message:any;
constructor(private ser:RegserviceService,private route:Router)
{
  
}
  ngOnInit(): void {
    console.log('component initiated')
  }
  public acReg()
  {
let response=this.ser.userAc1(this.ac)
response.subscribe(
  (data) => {
    this.message = data;
    alert('Successfully added');
    this.route.navigate(['/Home']); // Navigate on successful registration
  },
  (error) => {
    console.error('Error occurred:', error); // Handle error case
    // You might want to show an error message to the user
  }
);
  }
  
}
