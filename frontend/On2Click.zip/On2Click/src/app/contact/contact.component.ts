import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Complaints } from '../complaints';
import { RegserviceService } from '../regservice.service';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent implements OnInit{
  cid: string = '';
  message:string='';
  constructor(private router:ActivatedRoute,private route:Router,private ser:RegserviceService) { }
 cmp:Complaints=new Complaints(0,"","","","");

 ngOnInit(): void {
  console.log('conact initiated');
  this.router.params.subscribe(params => {
    this.cid = params['cid'];
    console.log('CID:is', this.cid);
    if (this.cid) {
      this.comReg();
    } else {
      console.error('CID parameter is not provided.');
    }
  });
}

public comReg() {
  console.log(this.cid);
     console.log('CID:', this.cid);
    this.ser.compReg(this.cmp, this.cid).subscribe(
      (response: any) => {
        if (response && response.success) {
          this.message = "Complaints Registered successfully...Please check Your Mail after One Working Day";
          alert(this.message); // Provide a success message
          // You might want to reset the form or do other actions after successful addition
        } else {
          this.message = "Complaints Registered successfully...Please check Your Mail after One Working Day";
          // Provide an appropriate error message
          alert(this.message);
          this.route.navigate([`/Profile/${this.cid}`]);
        }
      },
      (error) => {
        console.error('Error occurred:', error); // Handle error case
        // You might want to show an error message to the user
      }
    );
  }
}


