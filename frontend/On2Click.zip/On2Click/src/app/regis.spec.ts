import { Regis } from './regis';

describe('Regis', () => {
  it('should create an instance', () => {
    expect(new Regis()).toBeTruthy();
  });
});
