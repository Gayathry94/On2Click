import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LogserviceService {

  constructor(private http:HttpClient) { }
  public userLog1(lo:any):Observable<any>
  {
    return this.http.post("http://localhost:8080/user/login",lo)
  }
  public adminLog1(lo:any):Observable<any>
  {
    return this.http.post("http://localhost:8080/Admin/login",lo)
  }

}
