import { Component, OnInit } from '@angular/core';
import { ProfileserviceService } from '../profileservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Registration } from '../registration';

@Component({
  selector: 'app-dprofile',
  templateUrl: './dprofile.component.html',
  styleUrl: './dprofile.component.css'
})
export class DprofileComponent implements OnInit{
  cid: string = '';
  errorMessage: string = '';

  registration: Registration=new Registration("","","","","","","","","","","","","","")

constructor(private serv:ProfileserviceService,private router:ActivatedRoute,private route:Router)
{

}
ngOnInit(): void {
  console.log('delete initiated')


  
}


delData() {
  // Extract the cid parameter from the route snapshot
  const params = this.router.snapshot.params;
  this.cid = params['cid']; // 'cid' should match the parameter name defined in the route

  if (this.cid) {
    this.serv.deleteProfile(this.cid).subscribe(
      (data: Registration) => {
        this.registration = data; // Assign response data to registration object
        console.log(this.registration);
        if (this.registration) {
          this.route.navigate(['/Home']); 
        }
      },
      (error) => {
        console.log('Error deleting profile:', error);
        this.errorMessage = 'Error deleting profile. Please try again later.';
      }
    );
  } else {
    console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
  }
}

}






