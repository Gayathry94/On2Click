import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AproductComponent } from './aproduct.component';

describe('AproductComponent', () => {
  let component: AproductComponent;
  let fixture: ComponentFixture<AproductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AproductComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
