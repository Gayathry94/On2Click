import { Component, OnInit } from '@angular/core';
import { LogserviceService } from '../logservice.service';
import { Router } from '@angular/router';
import { Admin } from '../admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit {
  lo:Admin=new Admin("","")
  message:any;

  constructor(private serv:LogserviceService,private route:Router)
  {
  
  }

ngOnInit(): void {
    // Your initialization logic goes here
    console.log('Admin Component initialized');
  }

  public adminLog() {
    let resp = this.serv.adminLog1(this.lo);
    resp.subscribe(
      (data: any) => {
        if (data) {
          this.message = data;
          console.log('Response Data:', data);
          alert('Successful')
          this.route.navigate(['/Adminhome']); 
          // Handle the response data here
        } else {
          console.log('Data is not available in the response');
          // Handle the case where data is not available in the response
        }
      },
      (error) => {
        alert('Invalid Data');
        console.error('Error occurred:', error); // Handle error case
        // You might want to show an error message to the user
      }
    );
  }
  

}
