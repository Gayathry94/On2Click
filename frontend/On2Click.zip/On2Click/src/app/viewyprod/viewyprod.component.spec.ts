import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewyprodComponent } from './viewyprod.component';

describe('ViewyprodComponent', () => {
  let component: ViewyprodComponent;
  let fixture: ComponentFixture<ViewyprodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewyprodComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewyprodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
