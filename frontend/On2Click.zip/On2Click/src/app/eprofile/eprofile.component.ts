import { Component, OnInit } from '@angular/core';
import { ProfileserviceService } from '../profileservice.service';
import { Registration } from '../registration';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-eprofile',
  templateUrl: './eprofile.component.html',
  styleUrl: './eprofile.component.css'
})
export class EprofileComponent  implements OnInit{
cid: string = '';
errorMessage: string = '';
registration: Registration=new Registration("","","","","","","","","","","","","","")
constructor(private router:Router,private serv:ProfileserviceService,private route:ActivatedRoute)
{}
  ngOnInit() {
  console.log('view initiated in editprofile');
  this.route.params.subscribe(params => {
  this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
  console.log('CID:is', this.cid);
  if (this.cid) 
  {
      this.loadData(); // Call method to load profile if cid is provided
  }
  else 
  {
      console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
    
    }
  });
}
loadData(){
this.serv.viewProfile(this.cid).subscribe(
    (data: Registration) => {
      this.registration = data; // Assign response data to registration object
      console.log('object before edit',this.registration);
    },
   (error) => {
      console.log('Error fetching profile:', error);
      this.errorMessage = 'Error fetching profile. Please try again later.';
    }
  );
}
editSubmit()
{
  this.serv.editProfile(this.cid, this.registration).subscribe(
    (data: Registration) => {

        if (data && data.cid) {
          const cid = data.cid;
          console.log('CID:', cid);

      
      console.log('Edit successful');
      // Redirect to profile component or display a success message
      this.router.navigate([`/Profile/${cid}`]);
        }
        else {
          console.log('CID is not available in the response');
          // Handle the case where cid is not available in the response
        }
    },
    (error) => {
      console.log('Error editing profile:', error);
      this.errorMessage = 'Error editing profile. Please try again later.';
    }
  );
}
}







