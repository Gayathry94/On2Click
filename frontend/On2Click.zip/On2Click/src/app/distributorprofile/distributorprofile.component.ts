import { Component } from '@angular/core';

@Component({
  selector: 'app-distributorprofile',
  templateUrl: './distributorprofile.component.html',
  styleUrl: './distributorprofile.component.css'
})
export class DistributorprofileComponent {

}
