import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Complaints } from '../complaints';
@Component({
  selector: 'app-com',
  templateUrl: './com.component.html',
  styleUrl: './com.component.css'
})
export class ComComponent implements OnInit {
que:Complaints[]=[];
constructor(private route: ActivatedRoute, private router:Router, private ser:AdminService) { }
  ngOnInit(): void {
    console.log('complaint initiated')
    this.getCom();
  }
public getCom(){
  console.log('hi complaint');
  this.ser.getComplaint().subscribe((resp: Complaints[]) => {
    console.log(resp);
    this.que = resp;
  }, (error: HttpErrorResponse) => {
    console.log(error);
  });


}
}

