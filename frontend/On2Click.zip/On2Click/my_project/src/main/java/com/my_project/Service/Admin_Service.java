package com.my_project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my_project.Model.Admin;
import com.my_project.Model.Pickup;
import com.my_project.Repository.Admin_Repo;
import com.my_project.Repository.Pickup_Repo;

import jakarta.servlet.http.HttpSession;

@Service
public class Admin_Service {
	@Autowired
	Admin_Repo ar;

	@Autowired
	Pickup_Repo pr;

	public Admin adminAdd1(Admin admin) {
		
		return ar.save(admin);
	}



	public Admin logadmin(Admin a, HttpSession session) {
		Admin a1=ar.findByUname(a.getUname());
		if(a1.getPass().equals(a.getPass()))
		{
			session.setAttribute("aid",a1.getId());
			Integer adm=(Integer) session.getAttribute("aid");
			if(adm!=null)
			{
				System.out.println(adm);
				System.out.println("login sucess");
			}
			
			return a1;
		}
		else
		{
			System.out.println("Not a Valid User");
			return a1;
		}
		
		
	}



	public Pickup addpickup(Pickup p, HttpSession session) {
		int adm=(Integer) session.getAttribute("aid");
		if(adm!=0) {
			return pr.save(p);
		}
		else
		{
			return null;
		}
		
	}
	

}
