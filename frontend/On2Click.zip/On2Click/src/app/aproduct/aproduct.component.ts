import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { AdminService } from '../admin.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-aproduct',
  templateUrl: './aproduct.component.html',
  styleUrl: './aproduct.component.css'
})
export class AproductComponent implements OnInit {
 product:Product[]=[]
  type:string=''
  constructor(private route: ActivatedRoute, private router: Router, private ser:AdminService) { }
  ngOnInit(): void {
  console.log('aproduct home')
  this.route.params.subscribe(params => {
    this.type = params['type']; // 'cid' should match the parameter name defined in the route
    console.log('tc in admin profile:', this.type);
    if(this.type)
{
this.getProduct(this.type);
}
  });
}
public getProduct(type:string)

{

  console.log('hi product', type);
  this.ser.getProduct(type).subscribe((resp: Product[]) => {
    console.log(resp);
    this.product = resp;
  }, (error: HttpErrorResponse) => {
    console.log(error);
  });


}
}
