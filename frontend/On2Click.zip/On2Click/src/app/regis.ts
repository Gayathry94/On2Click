export class Regis {
    constructor(
        public name: string,
        public tc: string,
        public address: string,
        public landmark: string,
        public mailid: string,
        public phone: string,
        public adhar: string,
        public uname: string,
        public pass: string,
        public conp: string,
        public otp: string)
        {
            
        }
}
