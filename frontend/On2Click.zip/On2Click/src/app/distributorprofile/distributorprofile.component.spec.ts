import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributorprofileComponent } from './distributorprofile.component';

describe('DistributorprofileComponent', () => {
  let component: DistributorprofileComponent;
  let fixture: ComponentFixture<DistributorprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DistributorprofileComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DistributorprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
