import { Component, OnInit } from '@angular/core';
import { BuyService } from '../buy.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrl: './viewcart.component.css'
})
export class ViewcartComponent implements OnInit {
  cartItems: any[] = [];
  cid:string='';
  cid2:string=''
  total:number=0;
  id:number=0;
  message:string=''
  constructor(private serv:BuyService,private route:ActivatedRoute,private router:Router)
  {
    
  }
    ngOnInit(): void {
      console.log('viewcart initiated');

      this.route.params.subscribe(params => {
        const cid = params['cid'];
        console.log('CID value inside viewcart:', cid);

        this.serv.getCartItems(cid).subscribe(
          (data) => {
            this.cartItems = data;
            console.log(this.cartItems)
            this.calculateTotal(); // Calculate total initially
          },
          (error) => {
            console.error('Error fetching cart items:', error);
          }
        );
      });
    }

  calculateTotal(): void {
    this.total = 0;
    for (const item of this.cartItems) {
      this.total += item.price * item.quantity;
    }
 

}
public deleteItem(id: number) {
  this.route.params.subscribe(params => {
    const cid1 = params['cid'];
    console.log('CID value inside deletecart:', cid1);
    console.log(cid1);
    console.log(id);
    this.serv.deletecart(cid1, id).subscribe(
      (data) => {
        this.message = data;
        console.log(this.message);

      },
      (error) => {
        console.error('Error in deleting items:', error);
      }
    );
  });
}
buyProduct(cartItems: any) {
  this.route.params.subscribe(params => {
    const cid2 = params['cid'];
    console.log('CID value inside buy:', cid2);
    console.log(cartItems)
    console.log(cid2);
    
    // Call the service method to buy products
    this.serv.buyProduct(cid2,cartItems).subscribe(response => {
        console.log('Purchase successful:', response);
        alert('successfully purchased you can visit our store within one day')
        this.router.navigate(['/Customerprofile', cid2]);

        // Handle success response here
      },
      error => {
        console.error('Error occurred during purchase:', error);
        // Handle error response here
      }
    );
  });
}



}
