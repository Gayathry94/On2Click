export class Purchase {

    constructor(public id: number,
        public cid: string,
        public total: number,
        public date: string,
        public time: string
        )
        {

        }

}
