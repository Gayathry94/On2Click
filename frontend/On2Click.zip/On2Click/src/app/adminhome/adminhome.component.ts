import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent implements OnInit
 {
  tc:String=''
  type:string=''
  constructor(private route:ActivatedRoute,private router:Router ) { }
ngOnInit(): void {
  console.log('admin home')
}
setType(type: string): void {
  this.type = type;
  console.log('Type set admin view product:', this.type);
  
  // Now, construct the router link dynamically and navigate to it
  this.router.navigate(['/Aproduct', this.type]);
}
setTc(tc: string): void {
  this.tc = tc;
  console.log('Type set admin view profile:', this.tc);
  
  // Now, construct the router link dynamically and navigate to it
  this.router.navigate(['/Aprofile', this.tc]);
}
}
