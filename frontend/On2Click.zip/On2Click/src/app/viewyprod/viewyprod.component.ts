import { Component, OnInit } from '@angular/core';

import { Product } from '../product';

import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-viewyprod',
  templateUrl: './viewyprod.component.html',
  styleUrl: './viewyprod.component.css'
})
export class ViewyprodComponent implements OnInit{
  cid: string = '';

  errorMessage: string = '';

  productDetails:Product[]=[];

constructor(private ser:ProductserviceService,private router:ActivatedRoute)
{

}


  ngOnInit(): void {
    console.log('view initiated in view profile');
  this.router.params.subscribe(params => {
      this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
      console.log('CID:is', this.cid);
      if (this.cid) {
        this.getProducts(this.cid);
      } else {
        console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
      }
    });


  }
  public getProducts(cid:string)
  {
    this.ser.getProducts(cid).subscribe((resp:Product[])=>{
      console.log(resp);
      this.productDetails=resp
      
    },(error:HttpErrorResponse)=>{
      console.log(error);
    }
    );
  }
}
