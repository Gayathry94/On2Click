import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuerieComponent } from './querie.component';

describe('QuerieComponent', () => {
  let component: QuerieComponent;
  let fixture: ComponentFixture<QuerieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QuerieComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(QuerieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
