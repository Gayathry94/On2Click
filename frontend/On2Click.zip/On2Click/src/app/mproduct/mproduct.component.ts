import { Component } from '@angular/core';

@Component({
  selector: 'app-mproduct',
  templateUrl: './mproduct.component.html',
  styleUrl: './mproduct.component.css'
})
export class MproductComponent {

}
