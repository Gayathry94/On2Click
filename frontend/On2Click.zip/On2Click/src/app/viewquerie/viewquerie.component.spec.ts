import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewquerieComponent } from './viewquerie.component';

describe('ViewquerieComponent', () => {
  let component: ViewquerieComponent;
  let fixture: ComponentFixture<ViewquerieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewquerieComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewquerieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
