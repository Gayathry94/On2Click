import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

 
  constructor(private http: HttpClient) { }

  private apiUrl = 'http://localhost:8080/user/viewproduct';


  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }
  getProducts(cid:String): Observable<Product[]> {
    return this.http.get<Product[]>(`http://localhost:8080/user/viewp/${cid}`);
  }
  editProduct(cid: string, id: number, updatedProductData: any): Observable<Product[]> {
    return this.http.put<Product[]>(`http://localhost:8080/user/updateproduct/${cid}/${id}`, updatedProductData,{responseType:'text' as 'json'});
  }
  deleteProduct(cid:string,id:number):Observable<any> 
  { 
    return this.http.delete(`http://localhost:8080/user/deleteproduct/${cid}/${id}`,{responseType:'text' as 'json'});
  }
  getProtype(type:string,cid:String): Observable<Product[]> 
  {
    return this.http.get<Product[]>(`http://localhost:8080/customer/view/${type}/${cid}`);
  }
  
}