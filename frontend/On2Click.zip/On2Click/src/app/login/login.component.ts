import { Component, OnInit } from '@angular/core';
import { LogserviceService } from '../logservice.service';
import { Login } from '../login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
lo:Login=new Login("","")
message:any;
constructor(private ser:LogserviceService,private route:Router)
{

}
  ngOnInit(): void {
    // Your initialization logic goes here
    console.log('login Component initialized');
  }
  public userLog() {
    let resp = this.ser.userLog1(this.lo);
    resp.subscribe(
      (data: any) => {
        if (data && data.cid) {
          const cid = data.cid;
          console.log('CID:', cid);
          
          if (cid.startsWith('FAR')) {
            this.route.navigate([`/Profile/${cid}`]);
          } else if (cid.startsWith('ART')) {
            this.route.navigate([`/Profile/${cid}`]); 
          } else if (cid.startsWith('CON')) {
            this.route.navigate([`/Profile/${cid}`]);
          } else if (cid.startsWith('DES')) {
            this.route.navigate([`/Profile/${cid}`]);
          } else if (cid.startsWith('DIS')) {
            this.route.navigate([`/DistributorProfile/${cid}`]); 
          } else if (cid.startsWith('CUS')) {
            this.route.navigate([`/Customerprofile/${cid}`]); 
          }






        } else {
          console.log('CID is not available in the response');
          // Handle the case where cid is not available in the response
        }
      },
      (error) => {
        alert('Invalid Data');
        console.error('Error occurred:', error); // Handle error case
        // You might want to show an error message to the user
      }
    );
  }
  
  
}
