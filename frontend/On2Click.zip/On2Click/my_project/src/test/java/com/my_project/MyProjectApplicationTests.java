package com.my_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
