export class Querie {
    constructor(public id:number,public name:string,public mailid:string,public des:String )
    {

    }
}
