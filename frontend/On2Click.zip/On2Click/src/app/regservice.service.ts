import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Complaints } from './complaints';
import { Observable } from 'rxjs';
import { Product } from './product';
import { Querie } from './querie';

@Injectable({
  providedIn: 'root'
})
export class RegserviceService {

  constructor(private http:HttpClient) { }
  public userReg1(reg:any)
  {
    return this.http.post("http://localhost:8080/user/Reg",reg,{responseType:'text' as 'json'})
  }
  public userAc1(ac:any)
  {
    return this.http.post("http://localhost:8080/user/Account",ac,{responseType:'text' as 'json'})
  }
  public prodReg1(pr:any,cid:string):Observable<any>
  
  {
    return this.http.post<Product>(`http://localhost:8080/user/addNewProduct/${cid}`,pr);
  }
  compReg(cmp:any,cid:String):Observable<Complaints> 
  {
    return this.http.post<Complaints>(`http://localhost:8080/user/complaints/${cid}`,cmp,{responseType:'text' as 'json'});
  }
querieReg(que:any):Observable<Querie> 
{
  return this.http.post<Querie>(`http://localhost:8080/user/querie`,que,{responseType:'text' as 'json'});
}
}



