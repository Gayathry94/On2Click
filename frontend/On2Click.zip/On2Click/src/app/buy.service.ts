import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
import { Purchase } from './purchase';
@Injectable({
  providedIn: 'root'
})
export class BuyService {

  constructor(private http:HttpClient) { }
  public addtoCart(cid:string,id:number):Observable<any> 
  { 
    return this.http.get(`http://localhost:8080/customer/addcart/${cid}/${id}`);
  }
  getCartItems(cid: string): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:8080/customer/viewcart/${cid}`);
  }
  deletecart(cid1:string,id:number):Observable<any> 
  { 
    return this.http.delete(`http://localhost:8080/customer/deletecartitem/${cid1}/${id}`,{responseType:'text' as 'json'});
  }
  buyProduct(cid2: string, cartItems: any[]): Observable<any> {
    return this.http.post<any>(`http://localhost:8080/customer/buy/${cid2}`, cartItems);
}
  getOrders(cid: string): Observable<Purchase[]> {
    return this.http.get<Purchase[]>(`http://localhost:8080/customer/orders/${cid}`);
  }
}
