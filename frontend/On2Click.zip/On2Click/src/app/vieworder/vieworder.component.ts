import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BuyService } from '../buy.service';
import { Purchase } from '../purchase';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-vieworder',
  templateUrl: './vieworder.component.html',
  styleUrl: './vieworder.component.css'
})
export class VieworderComponent implements OnInit
{
  orders: Purchase[]=[];
  cid: string='';
  type: string = '';
  constructor(private route:ActivatedRoute,private router:Router,private ser:BuyService ) { }
  
  
  ngOnInit(): void {

console.log('customer profile initiated')

    this.route.params.subscribe(params => {
      this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
      console.log('CID value in customer profile:', this.cid);
      if(this.cid)
      {
        this.getOrder(this.cid);
      }
    });
  }
  setType(type: string): void {
    this.type = type;
    console.log('Type set in customer profile:', this.type);
    
    // Now, construct the router link dynamically and navigate to it
    this.router.navigate(['/Buy', this.type, this.cid]);
  }
  public getOrder(cid:string)
  {
    console.log('cid value in getorder',cid)
    this.ser.getOrders(cid).subscribe((resp:Purchase[])=>{
      console.log(resp);
      this.orders=resp
      
    },(error:HttpErrorResponse)=>{
      console.log(error);
    }
    );
  }


}
