import { Component, OnInit } from '@angular/core';
import { ProfileserviceService } from '../profileservice.service';
import { Registration } from '../registration';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-mprofile',
  templateUrl: './mprofile.component.html',
  styleUrl: './mprofile.component.css'
})
export class MprofileComponent implements OnInit {

  cid: string = '';

  errorMessage: string = '';

  registration: Registration=new Registration("","","","","","","","","","","","","","")



  constructor(private router:Router,private serv:ProfileserviceService,private route:ActivatedRoute)
{

}
ngOnInit() {
  console.log('view initiated in view profile');
this.route.params.subscribe(params => {
    this.cid = params['cid']; // 'cid' should match the parameter name defined in the route
    console.log('CID:is', this.cid);
    if (this.cid) {
      this.loadProfile(); // Call method to load profile if cid is provided
    } else {
      console.error('CID parameter is not provided.'); // Handle case where cid parameter is not provided
    }
  });




  
}

loadProfile(){
  this.serv.viewProfile(this.cid).subscribe(
    (data: Registration) => {
      this.registration = data; // Assign response data to registration object
      console.log(this.registration);
    },
    (error) => {
      console.log('Error fetching profile:', error);
      this.errorMessage = 'Error fetching profile. Please try again later.';
    }
  );
}


}
