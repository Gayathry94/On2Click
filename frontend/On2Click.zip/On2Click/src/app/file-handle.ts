import { SafeUrl } from "@angular/platform-browser";

export interface filehandle
{
    file:File,
   url:SafeUrl
}