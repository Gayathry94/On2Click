export class Login {
    constructor(public uname: string,
        public pass: string)
        {

        }
}
