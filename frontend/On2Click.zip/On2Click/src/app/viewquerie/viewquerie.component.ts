import { Component, OnInit } from '@angular/core';
import { Querie } from '../querie';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-viewquerie',
  templateUrl: './viewquerie.component.html',
  styleUrl: './viewquerie.component.css'
})
export class ViewquerieComponent implements OnInit {
  que:Querie[]=[];
  constructor(private route: ActivatedRoute, private router:Router, private ser:AdminService) { }

ngOnInit(): void {
  console.log('querie initiated')
    this.getQue();
}
public getQue(){
  console.log('hi Querie');
  this.ser.getquerie().subscribe((resp: Querie[]) => {
    console.log(resp);
    this.que = resp;
  }, (error: HttpErrorResponse) => {
    console.log(error);
  });


}


}
